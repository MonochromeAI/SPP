      <?php
      include "../Template-spp/header.php";
      include "../Template-spp/navbar.php";
      include "../Template-spp/sidebar.php";
      ?>
     

      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="card card-statistic-2">
                <div class="card-chart">
                </div>
                <div class="card-icon shadow-primary bg-primary">
                  <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Total Siswa</h4>
                  </div>
                  <div class="card-body">
                    3
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="card card-statistic-2">
                <div class="card-chart">

                </div>
                <div class="card-icon shadow-primary bg-primary">
                  <i class="fas fa-shopping-bag"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Total kelas</h4>
                  </div>
                  <div class="card-body">
                    3
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="card card-statistic-2">
                <div class="card-chart">

                </div>
                <div class="card-icon shadow-primary bg-primary">
                  <i class="fas fa-shopping-bag"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Total spp</h4>
                  </div>
                  <div class="card-body">
                    3
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <h4>Data Transaksi Pembayaran SPP</h4>
          <div class="card">
            <div class="card-header">
          <div class="card-body p-0">
          <div class="table-responsive table-invoice">
          <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">NISN</th>
      <th scope="col">NAMA</th>
      <th scope="col">Tanggal bayar</th>
      <th scope="col">Jumlah Bayar</th>
      <th scope="col">Petugas</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>212210</td>
      <td><div class="font-weight 600">Joseph</div></td>
      <td>21-11-2021</td>
      <td>Rp.400000</td>
      <td> <div class="badge badge-success">Hiko</div></td>
    </tr>
    <tr>
    <th scope="row">2</th>
      <td>212211</td>
      <td><div class="font-weight 600">Amar</div></td>
      <td>21-11-2021</td>
      <td>Rp.400000</td>
      <td> <div class="badge badge-success">Hiko</div></td>
    </tr>
  </tbody>
</table>
          </div>
          </div>
            </div>
          </div>
        </section>
      </div>
      <?php
       include "../Template-spp/footer.php" 
       ?>